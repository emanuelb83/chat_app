// Componente vuoto per chat non selezionata ad inizializzazione modalità Desktop
function EmptyChat() {
  return null; 
}

export default EmptyChat;
